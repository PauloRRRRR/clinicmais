<?php 

include_once 'pages/home/index.php';


?>